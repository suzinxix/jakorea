<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>WEB</title>
  </head>
  <body>
	  <h3>기본 정보</h3>
    <form action="program_create_process.php" method="POST">
      <p><input type="text" name="sort" placeholder="구분"></p>
		<p><input type="text" name="region" placeholder="지역"></p>
		<p><input type="text" name="prog_name" placeholder="프로그램 명"></p>
		<p><input type="text" name="class" placeholder="학급 수"></p>
		<p><input type="text" name="man" placeholder="남"></p>
		<p><input type="text" name="woman" placeholder="여"></p>
		<p><input type="text" name="studentnum" placeholder="학생수"></p>
		<p><input type="text" name="eduhour" placeholder="교육시간"></p>
		<p><input type="text" name="volun_university" placeholder="자봉(대)"></p>
		<p><input type="text" name="volun_office" placeholder="자봉(직)"></p>
		<p><input type="text" name="volun_retiree" placeholder="자봉(은)"></p>
		<p><input type="text" name="educator" placeholder="진행교사"></p>
	  
      
      <p><input type="submit"></p>
    </form>
  </body>
</html>